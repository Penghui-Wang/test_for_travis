#!/usr/bin/env python
# encoding: utf-8
c = 'j'
def uploadpy():
	b = 23
	if b is 23:
		print 'upload test'
	else:
		return None

def pypy():
	a = 13
	print 'this test is ok!'
	return a
